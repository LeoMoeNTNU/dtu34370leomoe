/* pseudocode: 
    generate the random array. 
    
    while time is less than time: 
        make a swap. 
        check if the swap is better, or how much worse it is. 
        the objective function needs to both return a value and a pointer. 
            it can write to an int pointer to get it that way. 

        if it is better, do the swap. 
        if it is worse, chose it with a likelihood based on how much time has been spent. 
        



*/
#include "types.h"
#include "randomlist.h"
#include "get.h"
#include "objective_function.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "printallprocs.h"
#include "writetofile.h"


//I would argue that it should get the value in so that it doesnt have to calculate it itself. 
//Then it doesnt get calculated twice!
int * iterationswap(info_t info, int oldvalue, int * ip, bool* improved, int* newval){
    
    int arrlen=info.len*info.len;
    int *newp=malloc(sizeof(int)*arrlen);
  //  printf("itswap 1\n");

    for(int i=0;i<arrlen;i++)newp[i]=ip[i];

    int index1=rand()%arrlen;
    int index2=rand()%arrlen;
    int temp=newp[index1];
    newp[index1]=newp[index2];
    newp[index2]=temp;
//printf("itswap 2\n");
    ap_and_val_t new=value(info,newp);

    //printf("itswap 3\n");
    if(new.val<oldvalue){
        //printf("itswap 4\n");
        free(ip);
        *newval=new.val;
        *improved=true;
        return newp;
        
    }
    *improved=false;
    free(newp);
    return 0;
}


int * re_order_neighbourhood(info_t info, int oldvalue, int * ip, bool* improved,int*newval){
    /*WHAT FUNCTION WILL DO: 
    1. Initialize some stuff. 
    2. decide which neighbourhood to work with. 
    
    */
    ap_and_val_t old_for_testing=value(info,ip);
    if(oldvalue!=old_for_testing.val){printf("something wrong with the value passed in!");}
      int arrlen=info.len*info.len;
    int *newp=malloc(sizeof(int)*arrlen);
  //  printf("itswap 1\n");

    for(int i=0;i<arrlen;i++)newp[i]=ip[i];

    //decide which neighbourhood to re-order. 
    int neighbourhood=rand()%info.len;
    //where the indexes will be: 
    int indexes[info.len];
    int insertionindex=0;
    int lowerbound=neighbourhood*info.len;
    int higherbound=(neighbourhood+1)*info.len;
    for(int i=0;i<arrlen;i++){
        //This doesnt yet do what I want it to do.
        
        if(newp[i]>=lowerbound&&newp[i]<higherbound){
            indexes[insertionindex]=i;
            insertionindex++;
        }
    }
    //printf("indexes and what's in them!\n");
    for(int i=0;i<info.len;i++){
       // printf("index %d: value:%d\n",indexes[i],newp[indexes[i]]);
    }

    //other way of doing it: 
    for(int i=0;i<info.len*2;i++){
        int p1=rand()%info.len;
        int p2=rand()%info.len;

        int ind1=indexes[p1];
        int ind2=indexes[p2];

        int  temp=newp[ind2];
        newp[ind2]=newp[ind1];
        newp[ind1]=temp;
    }
    //This should just do the swapping correctly. 
    //TODO: do the eval and return or not return. 

    ap_and_val_t newthingy=value(info,newp);
    if(newthingy.val<oldvalue){
        *improved=true;
        *newval=newthingy.val;
        free(ip);
        return newp;

    }else{
        *improved=false;
        free(newp);
        return ip;
    }



}


void wholefunc(char* cp, char* towriteto, int intime){
    startrandom();
        info_t info=get(cp);
    int len=info.len;
    int arrlen=len*len;
    int* arr=randomlist(arrlen);
    ap_and_val_t valmain=value(info,arr);
    bool improved;
    int bestvalue=valmain.val;
    int newval;
    int starttime=time(NULL);
    int iterations=0;
    int improvements=0;
    int deprovements=0;

    int *(*bestone)(info_t, int, int *, bool *, int *);
    int *(*worstone)(info_t, int, int *, bool *, int *);
    int *(*temp)(info_t, int, int *, bool *, int *);//this one is for swapping!
    bestone=iterationswap;
    worstone=re_order_neighbourhood;

    int bestonekarma=0;
    int worstonekarma=0;


    while(time(NULL)-starttime<intime){
    //for(int i=0;i<10000;i++){

        //What will happen now is that I will implement a system for running both. 
        //For each iteration, which will be 16 iterations:
        /*
        if iterations%5000==0: re-calibrate.
            cant be global improvements because then one will sometimes just take it. 
            as such, we just do local improvements.  
        if iterations/5000<3500: function =bestone
        if iterations/5000>=3500: function=worstone.

        if(improved&iterations%5000<3500):bestones++;
        else: worstones++;
        and then I need to run the fast one!
        */
        if(iterations%5000){
            if(bestonekarma/2<worstonekarma){
                temp=bestone;
                bestone=worstone;
                worstone=temp;
            }
            bestonekarma=0;
            worstonekarma=0;
        }
        int* potbet;
        if(iterations/5000<3500){potbet=bestone(info,bestvalue,arr,&improved,&newval);}
        else{potbet=worstone(info,bestvalue,arr,&improved,&newval);}
        //int * potentially_better=iterationswap(info,bestvalue,arr,&improved,&newval);
        //int * potentially_better=re_order_neighbourhood(info,bestvalue,arr,&improved,&newval);

        if(improved){
            if(iterations/5000<3500)bestonekarma++;
            if(iterations/5000>=3500)worstonekarma++;

            arr=potbet;//I dont have to free because it already got freed inside...
            improvements++;
            bestvalue=newval;
        }else{
            deprovements++;
        }
        iterations++;

    }
    //printf("got here 4\n");
    ap_and_val_t toprint=value(info,arr);
    printf("val: %d, total iterations: %d\n",toprint.val,iterations);
    printf(" improvements: %d, deprovements: %d\n",improvements,deprovements);
    //printallprocs(toprint.ap);
    writetofile(len,toprint.ap,towriteto);
}